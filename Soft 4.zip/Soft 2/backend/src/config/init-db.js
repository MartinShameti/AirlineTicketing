const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');

// Database path
const dbPath = path.join(__dirname, 'database.sqlite');

// Create database connection
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('Error connecting to database:', err);
        process.exit(1);
    }
    console.log('Connected to SQLite database');
});

// SQL schema
const schema = `
DROP TABLE IF EXISTS Airline_Admin;
CREATE TABLE Airline_Admin (
    AdminID INTEGER PRIMARY KEY AUTOINCREMENT,
    Name TEXT NOT NULL,
    Email TEXT UNIQUE NOT NULL,
    Password TEXT NOT NULL
);

DROP TABLE IF EXISTS Client_Passenger;
CREATE TABLE Client_Passenger (
    PassengerID INTEGER PRIMARY KEY AUTOINCREMENT,
    PName TEXT NOT NULL,
    Email TEXT UNIQUE NOT NULL,
    Password TEXT NOT NULL,
    Birthday DATE,
    Phone_Number TEXT,
    Gender TEXT,
    Loyalty_Points INTEGER DEFAULT 0,
    AdminID INTEGER,
    FOREIGN KEY (AdminID) REFERENCES Airline_Admin(AdminID)
);

DROP TABLE IF EXISTS Flight;
CREATE TABLE Flight (
    FlightID INTEGER PRIMARY KEY AUTOINCREMENT,
    Origin_Airport TEXT NOT NULL,
    Destination_Airport TEXT NOT NULL,
    Departure_Time DATETIME NOT NULL,
    Arrival_Time DATETIME NOT NULL,
    AdminID INTEGER,
    FOREIGN KEY (AdminID) REFERENCES Airline_Admin(AdminID)
);

DROP TABLE IF EXISTS Tech_Support_Maintenance;
CREATE TABLE Tech_Support_Maintenance (
    TechSupportID INTEGER PRIMARY KEY AUTOINCREMENT,
    Name TEXT NOT NULL,
    Email TEXT UNIQUE NOT NULL,
    Password TEXT NOT NULL
);

DROP TABLE IF EXISTS Payment;
CREATE TABLE Payment (
    PaymentID INTEGER PRIMARY KEY AUTOINCREMENT,
    Card_Holder TEXT NOT NULL,
    Card_Type TEXT NOT NULL,
    Card_Number TEXT NOT NULL,
    Security_Code TEXT NOT NULL,
    Expiration_Date TEXT NOT NULL,
    Amount DECIMAL(10,2) NOT NULL,
    PassengerID INTEGER,
    FOREIGN KEY (PassengerID) REFERENCES Client_Passenger(PassengerID)
);

DROP TABLE IF EXISTS Ticket;
CREATE TABLE Ticket (
    TicketID INTEGER PRIMARY KEY AUTOINCREMENT,
    FlightID INTEGER,
    PassengerID INTEGER,
    PaymentID INTEGER,
    Seat_Number TEXT NOT NULL,
    Class TEXT NOT NULL,
    Price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (FlightID) REFERENCES Flight(FlightID),
    FOREIGN KEY (PassengerID) REFERENCES Client_Passenger(PassengerID),
    FOREIGN KEY (PaymentID) REFERENCES Payment(PaymentID)
);

DROP TABLE IF EXISTS Booking;
CREATE TABLE Booking (
    BookingID INTEGER PRIMARY KEY AUTOINCREMENT,
    PassengerID INTEGER,
    FlightID INTEGER,
    Seat TEXT NOT NULL,
    Class TEXT NOT NULL,
    Price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (PassengerID) REFERENCES Client_Passenger(PassengerID),
    FOREIGN KEY (FlightID) REFERENCES Flight(FlightID)
);
`;

// Initialize database
db.serialize(() => {
    // Run schema
    db.exec(schema, (err) => {
        if (err) {
            console.error('Error creating tables:', err);
            process.exit(1);
        }
        console.log('Database tables created successfully');

        // Insert default admin user
        const adminPassword = 'admin123'; // You should change this in production
        db.run(
            'INSERT OR IGNORE INTO Airline_Admin (Name, Email, Password) VALUES (?, ?, ?)',
            ['Admin', 'admin@airline.com', adminPassword],
            function(err) {
                if (err) {
                    console.error('Error creating admin user:', err);
                } else {
                    console.log('Default admin user created');
                }
                // Close database connection
                db.close((err) => {
                    if (err) {
                        console.error('Error closing database:', err);
                    } else {
                        console.log('Database connection closed');
                    }
                });
            }
        );
    });
}); 