const sqlite3 = require('sqlite3').verbose();
const path = require('path');
require('dotenv').config();

// Use the DB_FILE from .env or default to ./src/config/database.sqlite
const dbPath = path.resolve(process.env.DB_FILE || './src/config/database.sqlite');
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('Error connecting to the database:', err);
    } else {
        console.log('Connected to the SQLite database.');
    }
});

console.log('Using database file:', dbPath);

const initializeDatabase = async () => {
    // You can add table creation logic here if needed
    console.log('Database initialized successfully');
};

module.exports = {
    db,
    initializeDatabase
};
