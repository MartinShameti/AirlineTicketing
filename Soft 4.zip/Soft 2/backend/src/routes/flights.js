const express = require('express');
const router = express.Router();
const { db } = require('../config/database');

// Get all flights (with optional filtering)
router.get('/', (req, res) => {
  const { origin, destination, date } = req.query;
  let query = 'SELECT * FROM Flight WHERE 1=1';
  const params = [];

  if (origin) {
    query += ' AND LOWER(Origin_Airport) = ?';
    params.push(origin.toLowerCase());
  }
  if (destination) {
    query += ' AND LOWER(Destination_Airport) = ?';
    params.push(destination.toLowerCase());
  }
  if (date) {
    query += ' AND DATE(Departure_Time) = ?';
    params.push(date);
  }

  db.all(query, params, (err, rows) => {
    if (err) {
      return res.status(500).json({ error: 'Database error' });
    }
    res.json(rows);
  });
});

// Create a new flight (admin)
router.post('/', (req, res) => {
  const { origin, destination, departure, arrival, seats, price, adminId } = req.body;
  db.run(
    'INSERT INTO Flight (Origin_Airport, Destination_Airport, Departure_Time, Arrival_Time, Seats, Price, AdminID) VALUES (?, ?, ?, ?, ?, ?, ?)',
    [origin, destination, departure, arrival, seats, price, adminId],
    function (err) {
      if (err) return res.status(500).json({ error: 'Database error' });
      res.status(201).json({ message: 'Flight created', flightId: this.lastID });
    }
  );
});

// Update a flight (admin)
router.put('/:id', (req, res) => {
  const { id } = req.params;
  const { origin, destination, departure, arrival, seats, price, adminId } = req.body;
  db.run(
    'UPDATE Flight SET Origin_Airport = ?, Destination_Airport = ?, Departure_Time = ?, Arrival_Time = ?, Seats = ?, Price = ?, AdminID = ? WHERE FlightID = ?',
    [origin, destination, departure, arrival, seats, price, adminId, id],
    function (err) {
      if (err) return res.status(500).json({ error: 'Database error' });
      if (this.changes === 0) return res.status(404).json({ error: 'Flight not found' });
      res.json({ message: 'Flight updated' });
    }
  );
});

// Delete a flight (admin)
router.delete('/:id', (req, res) => {
  const { id } = req.params;
  db.run(
    'DELETE FROM Flight WHERE FlightID = ?',
    [id],
    function (err) {
      if (err) return res.status(500).json({ error: 'Database error' });
      if (this.changes === 0) return res.status(404).json({ error: 'Flight not found' });
      res.json({ message: 'Flight deleted' });
    }
  );
});

// Get analytics (admin)
router.get('/analytics', (req, res) => {
  // Example: count total flights and total bookings
  db.get('SELECT COUNT(*) as totalFlights FROM Flight', [], (err, flightRow) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    db.get('SELECT COUNT(*) as totalBookings FROM Booking', [], (err2, bookingRow) => {
      if (err2) return res.status(500).json({ error: 'Database error' });
      res.json({
        totalFlights: flightRow.totalFlights,
        totalBookings: bookingRow.totalBookings
      });
    });
  });
});

// Get a single flight by ID
router.get('/:id', (req, res) => {
  const { id } = req.params;
  db.get('SELECT * FROM Flight WHERE FlightID = ?', [id], (err, flight) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    if (!flight) return res.status(404).json({ error: 'Flight not found' });
    res.json(flight);
  });
});

module.exports = router;
