const express = require('express');
const router = express.Router();
const { db } = require('../config/database');

// Get passenger profile by ID
router.get('/:id', (req, res) => {
  const { id } = req.params;
  db.get('SELECT * FROM Client_Passenger WHERE PassengerID = ?', [id], (err, user) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    if (!user) return res.status(404).json({ error: 'User not found' });
    res.json(user);
  });
});

// Update passenger profile by ID
router.put('/:id', (req, res) => {
  const { id } = req.params;
  const { name, email, password } = req.body;
  db.run(
    'UPDATE Client_Passenger SET PName = ?, Email = ?, Password = ? WHERE PassengerID = ?',
    [name, email, password, id],
    function (err) {
      if (err) return res.status(500).json({ error: 'Database error' });
      res.json({ message: 'Profile updated' });
    }
  );
});

// Get loyalty points for a passenger
router.get('/:id/loyalty', (req, res) => {
  const { id } = req.params;
  db.get('SELECT Loyalty_Points FROM Client_Passenger WHERE PassengerID = ?', [id], (err, row) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    if (!row) return res.status(404).json({ error: 'Passenger not found' });
    res.json({ loyaltyPoints: row.Loyalty_Points });
  });
});

module.exports = router;
