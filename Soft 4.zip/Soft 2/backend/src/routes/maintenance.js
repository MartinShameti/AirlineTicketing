const express = require('express');
const os = require('os');
const router = express.Router();
const { db } = require('../config/database');

// POST /api/system/health-check
router.post('/health-check', (req, res) => {
  const cpuUsage = os.loadavg()[0]; // 1-minute load average
  const memoryUsage = ((os.totalmem() - os.freemem()) / os.totalmem()) * 100;
  res.json({
    cpuUsage: cpuUsage.toFixed(2),
    memoryUsage: memoryUsage.toFixed(2)
  });
});

// GET /api/system/report
router.get('/report', (req, res) => {
  db.all('SELECT * FROM System_Performance', [], (err, rows) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    res.json(rows);
  });
});

module.exports = router; 