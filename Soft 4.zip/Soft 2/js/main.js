function loadNavbar(role) {
  let file = "";
  if (role === "passenger") file = "components/navbar-passenger.html";
  else if (role === "admin") file = "components/navbar-admin.html";
  else if (role === "tech") file = "components/navbar-tech.html";

  fetch(file)
    .then(res => {
      if (!res.ok) throw new Error("Navbar file not found");
      return res.text();
    })
    .then(html => {
      document.getElementById("navbar-placeholder").innerHTML = html;
    })
    .catch(err => console.error("Navbar load error:", err));
}