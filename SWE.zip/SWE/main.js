// Dummy login function (replace with real API call)
document.addEventListener("DOMContentLoaded", () => {
  const loginForm = document.getElementById("loginForm");
  const signupForm = document.getElementById("signupForm");

  if (loginForm) {
    loginForm.addEventListener("submit", (e) => {
      e.preventDefault();

      const email = document.getElementById("email").value.trim();
      const password = document.getElementById("password").value;

      // Simulated role-based redirection
      if (email === "admin@airline.com") {
        window.location.href = "admin/dashboard.html";
      } else if (email === "tech@airline.com") {
        window.location.href = "tech/maintenance.html";
      } else {
        window.location.href = "passenger/bookFlight.html";
      }
    });
  }

  if (signupForm) {
    signupForm.addEventListener("submit", (e) => {
      e.preventDefault();

      const name = document.getElementById("name").value.trim();
      const email = document.getElementById("email").value.trim();
      const password = document.getElementById("password").value;

      // Simulate account creation and redirect to login
      alert("Account created successfully. Please log in.");
      window.location.href = "login.html";
    });
  }
});
