document.addEventListener("DOMContentLoaded", () => {
  const addFlightForm = document.getElementById("addFlightForm");
  const flightTable = document.querySelector("#flightTable tbody");

  let flights = JSON.parse(localStorage.getItem("adminFlights")) || [];

  function renderFlights() {
    flightTable.innerHTML = "";
    flights.forEach((f, i) => {
      const row = document.createElement("tr");
      row.innerHTML = `
        <td>${f.flightNo}</td>
        <td>${f.departure}</td>
        <td>${f.destination}</td>
        <td>${new Date(f.datetime).toLocaleString()}</td>
        <td>€${f.price}</td>
        <td>${f.capacity}</td>
        <td>
          <button class="btn btn-sm btn-danger" onclick="deleteFlight(${i})">Cancel</button>
        </td>
      `;
      flightTable.appendChild(row);
    });
  }

  if (addFlightForm) {
    addFlightForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const newFlight = {
        flightNo: document.getElementById("flightNo").value,
        departure: document.getElementById("departure").value,
        destination: document.getElementById("destination").value,
        datetime: document.getElementById("datetime").value,
        price: parseFloat(document.getElementById("price").value),
        capacity: parseInt(document.getElementById("capacity").value)
      };
      flights.push(newFlight);
      localStorage.setItem("adminFlights", JSON.stringify(flights));
      renderFlights();
      addFlightForm.reset();
    });
  }

  renderFlights();
});

function deleteFlight(index) {
  const flights = JSON.parse(localStorage.getItem("adminFlights")) || [];
  flights.splice(index, 1);
  localStorage.setItem("adminFlights", JSON.stringify(flights));
  location.reload();
}
