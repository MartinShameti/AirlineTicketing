document.addEventListener("DOMContentLoaded", () => {
  const searchForm = document.getElementById("flightSearchForm");
  const resultsContainer = document.getElementById("flightResults");

  if (searchForm) {
    searchForm.addEventListener("submit", (e) => {
      e.preventDefault();

      // Get search input values
      const departure = document.getElementById("departure").value;
      const destination = document.getElementById("destination").value;
      const date = document.getElementById("date").value;
      const flightClass = document.getElementById("class").value;
      const maxPrice = parseFloat(document.getElementById("maxPrice").value || 9999);

      // Simulated flight results (replace with fetch to backend later)
      const dummyFlights = [
        {
          id: 1,
          flightNo: "AL123",
          from: "Rome",
          to: "Berlin",
          date: "2025-07-01T10:00",
          price: 120,
          airline: "SkyJet"
        },
        {
          id: 2,
          flightNo: "AL456",
          from: "Tirana",
          to: "Munich",
          date: "2025-07-01T14:30",
          price: 95,
          airline: "EagleAir"
        }
      ];

      const filtered = dummyFlights.filter(f =>
        f.from.toLowerCase().includes(departure.toLowerCase()) &&
        f.to.toLowerCase().includes(destination.toLowerCase()) &&
        f.price <= maxPrice
      );

      resultsContainer.innerHTML = "";

      if (filtered.length === 0) {
        resultsContainer.innerHTML = `<p class="text-muted">No flights found matching your criteria.</p>`;
        return;
      }

      filtered.forEach(flight => {
        const card = document.createElement("div");
        card.className = "col-md-6";

        card.innerHTML = `
          <div class="card shadow-sm">
            <div class="card-body">
              <h5 class="card-title">${flight.airline} – ${flight.flightNo}</h5>
              <p class="card-text">
                From <strong>${flight.from}</strong> to <strong>${flight.to}</strong><br>
                Departure: ${new Date(flight.date).toLocaleString()}<br>
                Class: ${flightClass} <br>
                Price: €${flight.price}
              </p>
              <button class="btn btn-success w-100" onclick="selectFlight('${flight.flightNo}')">Select & Proceed</button>
            </div>
          </div>
        `;
        resultsContainer.appendChild(card);
      });
    });
  }
});

// Redirect to seat selection or payment page
function selectFlight(flightNo) {
  alert(`Flight ${flightNo} selected. Redirecting to seat selection...`);
  window.location.href = "payment.html"; // Adjust to actual route
}
