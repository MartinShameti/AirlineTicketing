const express = require('express');
const router = express.Router();
const { db } = require('../config/database');

// Get all payments
router.get('/', (req, res) => {
  db.all('SELECT * FROM Payment', [], (err, rows) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    res.json(rows);
  });
});

// Create a new payment
router.post('/', (req, res) => {
  const { cardHolder, cardType, cardNumber, securityCode, expirationDate, amount, passengerId } = req.body;
  db.run(
    `INSERT INTO Payment (Card_Holder, Card_Type, Card_Number, Security_Code, Expiration_Date, Amount, PassengerID)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [cardHolder, cardType, cardNumber, securityCode, expirationDate, amount, passengerId],
    function (err) {
      if (err) return res.status(500).json({ error: 'Database error' });
      res.status(201).json({ message: 'Payment created', paymentId: this.lastID });
    }
  );
});

// Get financial report (admin)
router.get('/report/financial', (req, res) => {
  db.get('SELECT SUM(Amount) as totalRevenue FROM Payment', [], (err, row) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    res.json({ totalRevenue: row.totalRevenue || 0 });
  });
});

module.exports = router; 