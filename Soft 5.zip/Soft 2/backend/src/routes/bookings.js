const express = require('express');
const router = express.Router();
const { db } = require('../config/database');

// Get all bookings (for demo, returns all bookings)
router.get('/', (req, res) => {
  const { userId } = req.query;
  if (userId) {
    db.all(
      `SELECT Booking.BookingID, Booking.Seat, Booking.Class, Booking.Price, Booking.FlightID, Flight.Origin_Airport, Flight.Destination_Airport, Flight.Departure_Time, Flight.Arrival_Time, Flight.Price as FlightPrice
       FROM Booking
       JOIN Flight ON Booking.FlightID = Flight.FlightID
       WHERE Booking.PassengerID = ?`,
      [userId],
      (err, rows) => {
        if (err) return res.status(500).json({ error: 'Database error' });
        res.json(rows);
      }
    );
  } else {
    db.all('SELECT * FROM Booking', [], (err, rows) => {
      if (err) return res.status(500).json({ error: 'Database error' });
      res.json(rows);
    });
  }
});

// Create a new booking with optional loyalty points usage
router.post('/', (req, res) => {
  const { passengerId, flightId, seat, classType, basePrice, useLoyaltyPoints } = req.body;
  // Get passenger's loyalty points
  db.get('SELECT Loyalty_Points FROM Client_Passenger WHERE PassengerID = ?', [passengerId], (err, user) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    if (!user) return res.status(404).json({ error: 'Passenger not found' });
    let discount = 0;
    let pointsToUse = 0;
    let finalPrice = basePrice;
    if (useLoyaltyPoints) {
      pointsToUse = Math.min(user.Loyalty_Points, 100); // Max 100 points (100%)
      discount = (pointsToUse / 100) * basePrice;
      finalPrice = basePrice - discount;
    }
    // Insert booking with discounted price
    db.run(
      `INSERT INTO Booking (PassengerID, FlightID, Seat, Class, Price) VALUES (?, ?, ?, ?, ?)`,
      [passengerId, flightId, seat, classType, finalPrice],
      function (err2) {
        if (err2) return res.status(500).json({ error: 'Database error' });
        // Deduct used loyalty points and add 5 new points
        db.run(
          'UPDATE Client_Passenger SET Loyalty_Points = Loyalty_Points - ? + 5 WHERE PassengerID = ?',
          [pointsToUse, passengerId],
          function (err3) {
            if (err3) return res.status(500).json({ error: 'Booking made, but failed to update loyalty points' });
            res.status(201).json({ message: `Booking created. Used ${pointsToUse} loyalty points for $${discount.toFixed(2)} discount. 5 new points added.`, bookingId: this.lastID, finalPrice });
          }
        );
      }
    );
  });
});

// Add endpoint to reward loyalty points to all passengers of a cancelled flight
router.post('/reward-cancelled/:flightId', (req, res) => {
  const { flightId } = req.params;
  // Get all passengers who booked this flight
  db.all('SELECT PassengerID FROM Booking WHERE FlightID = ?', [flightId], (err, rows) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    if (!rows.length) return res.status(404).json({ error: 'No bookings for this flight' });
    // Add 20 loyalty points to each passenger
    const ids = rows.map(r => r.PassengerID);
    let updated = 0;
    ids.forEach((pid, idx) => {
      db.run('UPDATE Client_Passenger SET Loyalty_Points = Loyalty_Points + 20 WHERE PassengerID = ?', [pid], function (err2) {
        if (err2) return res.status(500).json({ error: 'Failed to update loyalty points for some passengers' });
        updated++;
        if (updated === ids.length) {
          res.json({ message: '20 loyalty points added to all passengers of cancelled flight' });
        }
      });
    });
  });
});

module.exports = router;