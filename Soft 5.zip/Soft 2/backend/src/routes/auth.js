const express = require('express');
const router = express.Router();
const { db } = require('../config/database');

// Passenger Registration
router.post('/register', (req, res) => {
  const { name, email, password, birthday, phone, gender } = req.body;
  db.run(
    'INSERT INTO Client_Passenger (PName, Email, Password, Birthday, Phone_Number, Gender, AdminID) VALUES (?, ?, ?, ?, ?, ?, ?)',
    [name, email, password, birthday, phone, gender, 1],
    function (err) {
      if (err) {
        console.error('Signup error:', err);
        return res.status(500).json({ error: 'Database error' });
      }
      res.status(201).json({ message: 'Registration successful', userId: this.lastID });
    }
  );
});

// Passenger Login
router.post('/login', (req, res) => {
  const { email, password } = req.body;
  db.get(
    'SELECT * FROM Client_Passenger WHERE Email = ? AND Password = ?',
    [email, password],
    (err, user) => {
      if (err) return res.status(500).json({ error: 'Database error' });
      if (!user) return res.status(401).json({ error: 'Invalid email or password' });
      res.json({
        message: 'Login successful',
        user: {
          id: user.PassengerID,
          name: user.PName,
          email: user.Email,
          role: 'passenger'
        }
      });
    }
  );
});

// Tech Support Login
router.post('/tech-login', (req, res) => {
  const { email, password } = req.body;
  db.get(
    'SELECT * FROM Tech_Support_Maintenance WHERE Email = ? AND Password = ?',
    [email, password],
    (err, user) => {
      if (err) return res.status(500).json({ error: 'Database error' });
      if (!user) return res.status(401).json({ error: 'Invalid email or password' });
      res.json({
        message: 'Login successful',
        user: {
          id: user.TechSupportID,
          name: user.Name,
          email: user.Email,
          role: 'tech'
        }
      });
    }
  );
});

// Passenger Reset Password
router.post('/reset-password', (req, res) => {
  const { email, newPassword } = req.body;
  db.run(
    'UPDATE Client_Passenger SET Password = ? WHERE Email = ?',
    [newPassword, email],
    function (err) {
      if (err) return res.status(500).json({ error: 'Database error' });
      if (this.changes === 0) return res.status(404).json({ error: 'User not found' });
      res.json({ message: 'Password reset successful' });
    }
  );
});

// Admin Login
router.post('/admin-login', (req, res) => {
  const { email, password } = req.body;
  db.get(
    'SELECT * FROM Airline_Admin WHERE Email = ? AND Password = ?',
    [email, password],
    (err, admin) => {
      if (err) return res.status(500).json({ error: 'Database error' });
      if (!admin) return res.status(401).json({ error: 'Invalid email or password' });
      res.json({
        message: 'Login successful',
        user: {
          id: admin.AdminID,
          name: admin.Name,
          email: admin.Email,
          role: 'admin'
        }
      });
    }
  );
});

module.exports = router; 