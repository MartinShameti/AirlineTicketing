const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const { db, initializeDatabase } = require('./src/config/database');
const authRoutes = require('./src/routes/auth');
const flightRoutes = require('./src/routes/flights');
const bookingRoutes = require('./src/routes/bookings');
const paymentRoutes = require('./src/routes/payments');
const profileRoutes = require('./src/routes/profile');
const maintenanceRoutes = require('./src/routes/maintenance');

// Load environment variables
dotenv.config();

// Create Express app
const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Initialize database
initializeDatabase()
    .then(() => {
        console.log('Database initialized successfully');
    })
    .catch(err => {
        console.error('Failed to initialize database:', err);
    });

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/flights', flightRoutes);
app.use('/api/bookings', bookingRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/profile', profileRoutes);
app.use('/api/system', maintenanceRoutes);

// System status/maintenance endpoint (for tech support)
app.get('/api/system/status', (req, res) => {
    // Check database connection
    db.get('SELECT 1', [], (err) => {
        if (err) {
            return res.status(500).json({
                status: 'error',
                message: 'Database connection failed',
                dbStatus: 'down',
                serverStatus: 'up'
            });
        }
        res.json({
            status: 'ok',
            message: 'Server and database are healthy',
            dbStatus: 'up',
            serverStatus: 'up'
        });
    });
});

// Test route
app.get('/api/test', (req, res) => {
    res.json({ message: 'API is working!' });
});

// Set port and start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server is running on port ${PORT}`);
});